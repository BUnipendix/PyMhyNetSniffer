from setuptools import setup

setup(
	name='PyMhyNetSniffer',
	version='0.1',
	packages=['MihoyoNetSniffer'],
	url='',
	license='',
	author='unipendix',
	author_email='',
	description='Akebi-Sniffer的替代品'
)
